const Employee = require("../models/employeeModel"); // Asegúrate de que el modelo esté bien referenciado
const { Response } = require("express");
const XLSX = require("xlsx");

class EmployeeController {
    static async getAllEmployees(req, res) {
        try {
            const employees = await Employee.findAll();

            res.json(employees);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async getEmployeeById(req, res) {
        try {
            const employee = await Employee.findById(req.params.id);

            if (!employee) {
                return res.status(404).json({ message: "Employee not found" });
            }

            res.json(employee);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async createEmployee(req, res) {
        try {
            const { name, paternal_surname, maternal_surname, hire_date, birth_date } = req.body;
            const employee = await Employee.create({ name, paternal_surname, maternal_surname, hire_date, birth_date });

            res.status(201).json(employee);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updateEmployee(req, res) {
        try {
            const { name, paternal_surname, maternal_surname, hire_date, birth_date } = req.body;
            const employee = await Employee.update(req.params.id, { name, paternal_surname, maternal_surname, hire_date, birth_date });

            if (!employee) {
                return res.status(404).json({ message: "Employee not found" });
            }

            res.json(employee);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async deleteEmployee(req, res) {
        try {
            const result = await Employee.delete(req.params.id);

            res.json(result);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async searchEmployee(req, res) {
        const searchTerm = req.query.q;

        if (!searchTerm) {
            return res.status(400).json({ message: "Search term is required." });
        }

        try {
            const employees = await Employee.search(searchTerm);
            res.json(employees);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async downloadEmployeesExcel(req, res) {
        try {
            // Obtener los datos de empleados
            const employees = await Employee.findAll();

            if (!employees || employees.length === 0) {
                return res.status(404).json({ message: "No employees found." });
            }

            // Crear una nueva hoja de trabajo (workbook) y agregar una hoja (worksheet)
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(employees);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Employees");

            // Generar el buffer del archivo Excel
            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            // Enviar el archivo Excel al cliente
            res.setHeader("Content-Disposition", "attachment; filename=employees.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);

        } catch (error) {
            console.error("Error generating Excel file:", error); // Log del error en el servidor
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = EmployeeController;
