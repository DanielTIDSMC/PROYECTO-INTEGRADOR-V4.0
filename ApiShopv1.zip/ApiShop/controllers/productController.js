const Product = require("../models/productModel"); // Asegúrate de que el modelo esté bien referenciado
const { Response } = require("express");
const XLSX = require("xlsx");

class ProductController {
    static async getAllProducts(req, res) {
        try {
            const products = await Product.findAll();

            res.json(products);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async getProductById(req, res) {
        try {
            const product = await Product.findById(req.params.id);

            if (!product) {
                return res.status(404).json({ message: "Product not found" });
            }

            res.json(product);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async createProduct(req, res) {
        try {
            const { name, price, stock, expiration_date, id_category, max_capacity, min_capacity } = req.body;
            const product = await Product.create({ name, price, stock, expiration_date, id_category, max_capacity, min_capacity });

            res.status(201).json(product);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updateProduct(req, res) {
        try {
            const { name, price, stock, expiration_date, id_category, max_capacity, min_capacity } = req.body;
            const product = await Product.update(req.params.id, { name, price, stock, expiration_date, id_category, max_capacity, min_capacity });

            if (!product) {
                return res.status(404).json({ message: "Product not found" });
            }

            res.json(product);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async deleteProduct(req, res) {
        try {
            const result = await Product.delete(req.params.id);

            res.json(result);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async searchProduct(req, res) {
        const searchTerm = req.query.q;

        if (!searchTerm) {
            return res.status(400).json({ message: "Search term is required." });
        }

        try {
            const products = await Product.search(searchTerm);
            res.json(products);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async downloadProductsExcel(req, res) {
        try {
            // Obtener los datos de productos
            const products = await Product.findAll();

            if (!products || products.length === 0) {
                return res.status(404).json({ message: "No products found." });
            }

            // Crear una nueva hoja de trabajo (workbook) y agregar una hoja (worksheet)
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(products);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Products");

            // Generar el buffer del archivo Excel
            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            // Enviar el archivo Excel al cliente
            res.setHeader("Content-Disposition", "attachment; filename=products.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);

        } catch (error) {
            console.error("Error generating Excel file:", error); // Log del error en el servidor
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = ProductController;
