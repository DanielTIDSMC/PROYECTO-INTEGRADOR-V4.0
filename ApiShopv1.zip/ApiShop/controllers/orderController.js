const Order = require("../models/orderModel"); // Asegúrate de que el modelo esté bien referenciado
const { Response } = require("express");
const XLSX = require("xlsx");

class OrderController {
    static async getAllOrders(req, res) {
        try {
            const orders = await Order.findAll();

            res.json(orders);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async getOrderById(req, res) {
        try {
            const order = await Order.findById(req.params.id);

            if (!order) {
                return res.status(404).json({ message: "Order not found" });
            }

            res.json(order);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async createOrder(req, res) {
        try {
            const { address, order_date } = req.body;
            const order = await Order.create({ address, order_date });

            res.status(201).json(order);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updateOrder(req, res) {
        try {
            const { address, order_date } = req.body;
            const order = await Order.update(req.params.id, { address, order_date });

            if (!order) {
                return res.status(404).json({ message: "Order not found" });
            }

            res.json(order);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async deleteOrder(req, res) {
        try {
            const result = await Order.delete(req.params.id);

            res.json(result);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async searchOrder(req, res) {
        const searchTerm = req.query.q;

        if (!searchTerm) {
            return res.status(400).json({ message: "Search term is required." });
        }

        try {
            const orders = await Order.search(searchTerm);
            res.json(orders);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async downloadOrdersExcel(req, res) {
        try {
            // Obtener los datos de órdenes
            const orders = await Order.findAll();

            if (!orders || orders.length === 0) {
                return res.status(404).json({ message: "No orders found." });
            }

            // Crear una nueva hoja de trabajo (workbook) y agregar una hoja (worksheet)
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(orders);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Orders");

            // Generar el buffer del archivo Excel
            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            // Enviar el archivo Excel al cliente
            res.setHeader("Content-Disposition", "attachment; filename=orders.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);

        } catch (error) {
            console.error("Error generating Excel file:", error); // Log del error en el servidor
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = OrderController;
