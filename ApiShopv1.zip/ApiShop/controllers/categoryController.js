const Category = require("../models/categoryModel");
const XLSX = require("xlsx");
const { Response } = require("express");

class CategoryController {
    static async getAllCategories(req, res) {
        try {
            const categories = await Category.findAll();

            res.json(categories);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async getCategoryById(req, res) {
        try {
            const category = await Category.findById(req.params.id);

            if (!category) {
                return res.status(404).json({ message: "Category not found" });
            }

            res.json(category);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async createCategory(req, res) {
        try {
            const category = await Category.create(req.body);

            res.status(201).json(category);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updateCategory(req, res) {
        try {
            const category = await Category.update(req.params.id, req.body);

            if (!category) {
                return res.status(404).json({ message: "Category not found" });
            }

            res.json(category);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async deleteCategory(req, res) {
        try {
            const result = await Category.delete(req.params.id);

            res.json(result);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async searchCategories(req, res) {
        const searchTerm = req.query.q;

        if (!searchTerm) {
            return res.status(400).json({ message: "Search term is required." });
        }

        try {
            const categories = await Category.search(searchTerm);
            res.json(categories);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async downloadCategoriesExcel(req, res) {
        try {
            // Obtener los datos de las categorías
            const categories = await Category.findAll();
    
            if (!categories || categories.length === 0) {
                return res.status(404).json({ message: "No categories found." });
            }
    
            // Crear una nueva hoja de trabajo (workbook) y agregar una hoja (worksheet)
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(categories);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Categories");
    
            // Generar el buffer del archivo Excel
            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
    
            // Enviar el archivo Excel al cliente
            res.setHeader("Content-Disposition", "attachment; filename=categories.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);
    
        } catch (error) {
            console.error("Error generating Excel file:", error); // Log del error en el servidor
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = CategoryController;
