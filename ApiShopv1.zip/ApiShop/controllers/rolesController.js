const Roles = require("../models/rolesModel"); 
const { Response } = require("express");

class RolesController {
    static async getAllRoles(req, res) {
        try {
            const roles = await Roles.findAll();

            res.json(roles);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async getRoleById(req, res) {
        try {
            const role = await Roles.findById(req.params.id);

            if (!role) {
                return res.status(404).json({ message: "Role not found" });
            }

            res.json(role);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async createRole(req, res) {
        try {
            const role = await Roles.create(req.body);

            res.status(201).json(role);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updateRole(req, res) {
        try {
            const role = await Roles.update(req.params.id, req.body);

            if (!role) {
                return res.status(404).json({ message: "Role not found" });
            }

            res.json(role);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async deleteRole(req, res) {
        try {
            const result = await Roles.delete(req.params.id);

            res.json(result);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async searchRoles(req, res) {
        const searchTerm = req.query.q;

        if (!searchTerm) {
            return res.status(400).json({ message: "Search term is required." });
        }

        try {
            const roles = await Roles.search(searchTerm);
            res.json(roles);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async downloadRolesExcel(req, res) {
        try {
            // Obtener los datos de los roles
            const roles = await Roles.findAll();

            if (!roles || roles.length === 0) {
                return res.status(404).json({ message: "No roles found." });
            }

            // Crear una nueva hoja de trabajo (workbook) y agregar una hoja (worksheet)
            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(roles);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Roles");

            // Generar el buffer del archivo Excel
            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            // Enviar el archivo Excel al cliente
            res.setHeader("Content-Disposition", "attachment; filename=roles.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);

        } catch (error) {
            console.error("Error generating Excel file:", error); // Log del error en el servidor
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = RolesController;
