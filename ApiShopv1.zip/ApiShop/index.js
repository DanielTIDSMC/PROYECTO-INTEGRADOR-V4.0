const express = require('express');
const categoryRoute = require('./routes/categoryRoute'); 
const rolesRoute = require('./routes/rolesRoute'); 
const rolesDesignRoute = require('./routes/rolesDesignRoute');
const employeeRoute = require('./routes/employeeRoute');
const userRoute = require('./routes/userRoute'); 
const productRoute = require('./routes/productRoute'); 
const orderRoute = require('./routes/orderRoute'); 
require('dotenv').config();

const app = express();

app.use(express.json());

// Prefijo para las rutas de categorías, roles, rolesDesign, empleados, usuarios, productos, y órdenes
app.use('/api', categoryRoute); 
app.use('/api', rolesRoute); 
app.use('/api', rolesDesignRoute);
app.use('/api', employeeRoute); 
app.use('/api', userRoute); 
app.use('/api', productRoute); 
app.use('/api', orderRoute); 

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log("SERVER IS RUNNING ON PORT: " + PORT);
});
