const pool = require('../config/db');

class Employee {

    static async findAll(filters = {}) {
        const { name, paternal_surname, maternal_surname, hire_date, birth_date } = filters;
        let query = 'SELECT * FROM employee WHERE 1=1';
        const queryParams = [];

        // Agregar filtros opcionales a la consulta
        if (name) {
            queryParams.push(`%${name}%`);
            query += ` AND name ILIKE $${queryParams.length}`;
        }
        if (paternal_surname) {
            queryParams.push(`%${paternal_surname}%`);
            query += ` AND paternal_surname ILIKE $${queryParams.length}`;
        }
        if (maternal_surname) {
            queryParams.push(`%${maternal_surname}%`);
            query += ` AND maternal_surname ILIKE $${queryParams.length}`;
        }
        if (hire_date) {
            queryParams.push(hire_date);
            query += ` AND hire_date = $${queryParams.length}`;
        }
        if (birth_date) {
            queryParams.push(birth_date);
            query += ` AND birth_date = $${queryParams.length}`;
        }

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    static async create(data) {
        const { name, paternal_surname, maternal_surname, hire_date, birth_date } = data;
        const result = await pool.query(
            'INSERT INTO employee (name, paternal_surname, maternal_surname, hire_date, birth_date) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [name, paternal_surname, maternal_surname, hire_date, birth_date]
        );
        return result.rows[0];
    }

    static async update(id, data) {
        const { name, paternal_surname, maternal_surname, hire_date, birth_date } = data;
        const result = await pool.query(
            'UPDATE employee SET name = $1, paternal_surname = $2, maternal_surname = $3, hire_date = $4, birth_date = $5, updated_at = CURRENT_TIMESTAMP WHERE id_employee = $6 RETURNING *',
            [name, paternal_surname, maternal_surname, hire_date, birth_date, id]
        );
        return result.rows[0];
    }

    static async delete(id) {
        await pool.query('DELETE FROM employee WHERE id_employee = $1', [id]);
        return { message: 'Employee deleted successfully' };
    }

    static async search(searchTerm) {
        const query = `
            SELECT * FROM employee 
            WHERE name ILIKE $1 
            OR paternal_surname ILIKE $1 
            OR maternal_surname ILIKE $1
        `; // Asumiendo que quieres buscar en nombre y apellidos
        const result = await pool.query(query, [`%${searchTerm}%`]);
        return result.rows;
    }
}

module.exports = Employee;
