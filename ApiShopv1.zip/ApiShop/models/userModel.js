const pool = require('../config/db');

class User {

    static async findAll(filters = {}) {
        const { name, creation_date, sale_detail_id, roles_id, employee_id } = filters;
        let query = 'SELECT * FROM users WHERE 1=1';
        const queryParams = [];

        // Agregar filtros opcionales a la consulta
        if (name) {
            queryParams.push(`%${name}%`);
            query += ` AND name ILIKE $${queryParams.length}`;
        }
        if (creation_date) {
            queryParams.push(creation_date);
            query += ` AND creation_date = $${queryParams.length}`;
        }
        if (sale_detail_id) {
            queryParams.push(sale_detail_id);
            query += ` AND sale_detail_id = $${queryParams.length}`;
        }
        if (roles_id) {
            queryParams.push(roles_id);
            query += ` AND roles_id = $${queryParams.length}`;
        }
        if (employee_id) {
            queryParams.push(employee_id);
            query += ` AND employee_id = $${queryParams.length}`;
        }

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    static async create(data) {
        const { name, password, creation_date, sale_detail_id, roles_id, employee_id } = data;
        const result = await pool.query(
            'INSERT INTO users (name, password, creation_date, sale_detail_id, roles_id, employee_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
            [name, password, creation_date, sale_detail_id, roles_id, employee_id]
        );
        return result.rows[0];
    }

    static async update(id, data) {
        const { name, password, creation_date, sale_detail_id, roles_id, employee_id } = data;
        const result = await pool.query(
            'UPDATE users SET name = $1, password = $2, creation_date = $3, sale_detail_id = $4, roles_id = $5, employee_id = $6, updated_at = CURRENT_TIMESTAMP WHERE id_user = $7 RETURNING *',
            [name, password, creation_date, sale_detail_id, roles_id, employee_id, id]
        );
        return result.rows[0];
    }

    static async delete(id) {
        await pool.query('DELETE FROM users WHERE id_user = $1', [id]);
        return { message: 'User deleted successfully' };
    }

    static async search(searchTerm) {
        const query = `
            SELECT * FROM users 
            WHERE name ILIKE $1
        `; // Buscando por nombre, puedes ajustar si quieres buscar también por otros atributos
        const result = await pool.query(query, [`%${searchTerm}%`]);
        return result.rows;
    }
}

module.exports = User;
