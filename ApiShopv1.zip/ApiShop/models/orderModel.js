const pool = require('../config/db');

class Order {

    static async findAll(filters = {}) {
        const { address, order_date } = filters;
        let query = 'SELECT * FROM orders WHERE 1=1';
        const queryParams = [];

        // Agregar filtros opcionales a la consulta
        if (address) {
            queryParams.push(`%${address}%`);
            query += ` AND address ILIKE $${queryParams.length}`;
        }
        if (order_date) {
            queryParams.push(order_date);
            query += ` AND order_date = $${queryParams.length}`;
        }

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    static async create(data) {
        const { address, order_date } = data;
        const result = await pool.query(
            'INSERT INTO orders (address, order_date) VALUES ($1, $2) RETURNING *',
            [address, order_date]
        );
        return result.rows[0];
    }

    static async update(id, data) {
        const { address, order_date } = data;
        const result = await pool.query(
            'UPDATE orders SET address = $1, order_date = $2, updated_at = CURRENT_TIMESTAMP WHERE id_order = $3 RETURNING *',
            [address, order_date, id]
        );
        return result.rows[0];
    }

    static async delete(id) {
        await pool.query('DELETE FROM orders WHERE id_order = $1', [id]);
        return { message: 'Order deleted successfully' };
    }

    static async search(searchTerm) {
        const query = `
            SELECT * FROM orders 
            WHERE address ILIKE $1
        `; // Buscando por dirección, puedes ajustar si quieres buscar también por otros atributos
        const result = await pool.query(query, [`%${searchTerm}%`]);
        return result.rows;
    }
}

module.exports = Order;
