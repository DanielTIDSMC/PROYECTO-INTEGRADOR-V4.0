const pool = require('../config/db');

class RolesDesign {

    static async findAll(filters = {}) {
        const { roles_id } = filters; // Cambia 'namerols' a 'roles_id' si necesitas filtrar por roles_id
        let query = 'SELECT * FROM rols_design WHERE 1=1';
        const queryParams = [];

        // Agregar filtros opcionales a la consulta
        if (roles_id) {
            queryParams.push(roles_id);
            query += ` AND roles_id = $${queryParams.length}`; // Cambia según tus necesidades de filtrado
        }

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    static async create(data) {
        const { roles_id } = data; // Cambia 'namerols' a 'roles_id'
        const result = await pool.query(
            'INSERT INTO rols_design (roles_id) VALUES ($1) RETURNING *',
            [roles_id]
        );
        return result.rows[0];
    }

    static async update(id, data) {
        const { roles_id } = data; // Cambia 'namerols' a 'roles_id'
        const result = await pool.query(
            'UPDATE rols_design SET roles_id = $1, updated_at = CURRENT_TIMESTAMP WHERE id_rols_design = $2 RETURNING *',
            [roles_id, id]
        );
        return result.rows[0];
    }

    static async delete(id) {
        await pool.query('DELETE FROM rols_design WHERE id_rols_design = $1', [id]);
        return { message: 'RolesDesign deleted successfully' };
    }

    static async search(searchTerm) {
        const query = `
            SELECT * FROM rols_design 
            WHERE roles_id::text ILIKE $1
        `; // Asumiendo que quieres buscar en roles_id
        const result = await pool.query(query, [`%${searchTerm}%`]);
        return result.rows;
    }
}

module.exports = RolesDesign;
