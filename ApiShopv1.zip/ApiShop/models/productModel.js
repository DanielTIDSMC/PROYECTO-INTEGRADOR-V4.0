const pool = require('../config/db');

class Product {

    static async findAll(filters = {}) {
        const { name, price, stock, expiration_date, id_category } = filters;
        let query = 'SELECT * FROM product WHERE 1=1';
        const queryParams = [];

        // Agregar filtros opcionales a la consulta
        if (name) {
            queryParams.push(`%${name}%`);
            query += ` AND name ILIKE $${queryParams.length}`;
        }
        if (price) {
            queryParams.push(price);
            query += ` AND price = $${queryParams.length}`;
        }
        if (stock) {
            queryParams.push(stock);
            query += ` AND stock = $${queryParams.length}`;
        }
        if (expiration_date) {
            queryParams.push(expiration_date);
            query += ` AND expiration_date = $${queryParams.length}`;
        }
        if (id_category) {
            queryParams.push(id_category);
            query += ` AND id_category = $${queryParams.length}`;
        }

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    static async create(data) {
        const { name, price, stock, expiration_date, id_category, max_capacity, min_capacity } = data;
        const result = await pool.query(
            'INSERT INTO product (name, price, stock, expiration_date, id_category, max_capacity, min_capacity) VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *',
            [name, price, stock, expiration_date, id_category, max_capacity, min_capacity]
        );
        return result.rows[0];
    }

    static async update(id, data) {
        const { name, price, stock, expiration_date, id_category, max_capacity, min_capacity } = data;
        const result = await pool.query(
            'UPDATE product SET name = $1, price = $2, stock = $3, expiration_date = $4, id_category = $5, max_capacity = $6, min_capacity = $7, updated_at = CURRENT_TIMESTAMP WHERE id_product = $8 RETURNING *',
            [name, price, stock, expiration_date, id_category, max_capacity, min_capacity, id]
        );
        return result.rows[0];
    }

    static async delete(id) {
        await pool.query('DELETE FROM product WHERE id_product = $1', [id]);
        return { message: 'Product deleted successfully' };
    }

    static async search(searchTerm) {
        const query = `
            SELECT * FROM product 
            WHERE name ILIKE $1
        `; // Buscando por nombre, puedes ajustar si quieres buscar también por otros atributos
        const result = await pool.query(query, [`%${searchTerm}%`]);
        return result.rows;
    }
}

module.exports = Product;
