const express = require('express');
const RolesController = require('../controllers/rolesController'); 
const { validateRoles, validateSearch } = require('../middlewares/validation'); 
const router = express.Router();

router.get('/roles', RolesController.getAllRoles);
router.get('/roles/:id', RolesController.getRoleById);
router.post('/roles', validateRoles, RolesController.createRole);
router.put('/roles/:id', validateRoles, RolesController.updateRole);
router.delete('/roles/:id', RolesController.deleteRole);
router.get('/roles/search', validateSearch, RolesController.searchRoles);

module.exports = router;
