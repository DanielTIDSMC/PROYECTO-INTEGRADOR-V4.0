const express = require('express');
const EmployeeController = require('../controllers/employeeController'); 
const { validateEmployee, validateSearch } = require('../middlewares/validation'); 
const router = express.Router();

router.get('/employees', EmployeeController.getAllEmployees);
router.get('/employees/:id', EmployeeController.getEmployeeById);
router.post('/employees', validateEmployee, EmployeeController.createEmployee);
router.put('/employees/:id', validateEmployee, EmployeeController.updateEmployee);
router.delete('/employees/:id', EmployeeController.deleteEmployee);
router.get('/employees/search', validateSearch, EmployeeController.searchEmployee);

module.exports = router;
