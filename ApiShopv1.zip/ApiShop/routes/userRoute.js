const express = require('express');
const UserController = require('../controllers/userController'); 
const { validateUser, validateSearch } = require('../middlewares/validation'); 
const router = express.Router();

router.get('/users', UserController.getAllUsers);
router.get('/users/:id', UserController.getUserById);
router.post('/users', validateUser, UserController.createUser);
router.put('/users/:id', validateUser, UserController.updateUser);
router.delete('/users/:id', UserController.deleteUser);
router.get('/users/search', validateSearch, UserController.searchUser);

module.exports = router;
