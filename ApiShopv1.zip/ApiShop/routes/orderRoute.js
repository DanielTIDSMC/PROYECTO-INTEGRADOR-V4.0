const express = require('express');
const OrderController = require('../controllers/orderController'); 
const { validateOrder, validateSearch } = require('../middlewares/validation'); 
const router = express.Router();

router.get('/orders', OrderController.getAllOrders);
router.get('/orders/:id', OrderController.getOrderById);
router.post('/orders', validateOrder, OrderController.createOrder);
router.put('/orders/:id', validateOrder, OrderController.updateOrder);
router.delete('/orders/:id', OrderController.deleteOrder);
router.get('/orders/search', validateSearch, OrderController.searchOrder);

module.exports = router;
