const express = require('express');
const CategoryController = require('../controllers/categoryController');
const { validateCategory, validateSearch } = require('../middlewares/validation');
const router = express.Router();

// Rutas para categorías
router.get('/categories', CategoryController.getAllCategories);
router.get('/categories/:id', CategoryController.getCategoryById);
router.post('/categories', validateCategory, CategoryController.createCategory);
router.put('/categories/:id', validateCategory, CategoryController.updateCategory);
router.delete('/categories/:id', CategoryController.deleteCategory);
router.get('/categories/search', validateSearch, CategoryController.searchCategories);

module.exports = router;

