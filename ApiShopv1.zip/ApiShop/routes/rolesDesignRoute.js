const express = require('express');
const RolesDesignController = require('../controllers/rolesDesignController'); 
const { validateRolesDesign, validateSearch } = require('../middlewares/validation'); 
const router = express.Router();

// Rutas para RolesDesign
router.get('/rolesDesign', RolesDesignController.getAllRolesDesign); 
router.get('/rolesDesign/:id', RolesDesignController.getRolesDesignById); 
router.post('/rolesDesign', validateRolesDesign, RolesDesignController.createRolesDesign);
router.put('/rolesDesign/:id', validateRolesDesign, RolesDesignController.updateRolesDesign); 

module.exports = router;
