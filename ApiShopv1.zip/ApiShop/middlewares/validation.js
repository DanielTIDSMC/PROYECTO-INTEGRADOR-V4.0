const { body, validationResult } = require('express-validator');

// Validación para Category
const validateCategory = [
    body('name')
        .notEmpty()
        .withMessage('Name is required')
        .isLength({ max: 100 })
        .withMessage('Name must be at most 100 characters long'),

    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    },
];

// Validación para Roles
const validateRoles = [
    body('namerols')
        .notEmpty()
        .withMessage('Role name is required')
        .isLength({ max: 50 })
        .withMessage('Role name must be at most 50 characters long'),

    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    },
];

// Validación para RolesDesign
const validateRolesDesign = [
    body('roles_id')
        .notEmpty()
        .withMessage('Role ID is required')
        .isInt()
        .withMessage('Role ID must be an integer'),

    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    },
];

// Validación para Employee
const validateEmployee = [
    body('name')
        .notEmpty()
        .withMessage('Name is required')
        .isLength({ max: 50 })
        .withMessage('Name must be at most 50 characters long'),
    
    body('paternal_surname')
        .notEmpty()
        .withMessage('Paternal surname is required')
        .isLength({ max: 50 })
        .withMessage('Paternal surname must be at most 50 characters long'),
    
    body('maternal_surname')
        .optional() // Puede ser opcional si no es obligatorio en tu base de datos
        .isLength({ max: 50 })
        .withMessage('Maternal surname must be at most 50 characters long'),
    
    body('hire_date')
        .notEmpty()
        .withMessage('Hire date is required')
        .isDate()
        .withMessage('Hire date must be a valid date'),
    
    body('birth_date')
        .notEmpty()
        .withMessage('Birth date is required')
        .isDate()
        .withMessage('Birth date must be a valid date'),

    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    },
];

// Validación para Users
const validateUser = [
    body('name')
        .notEmpty()
        .withMessage('Name is required')
        .isLength({ max: 50 })
        .withMessage('Name must be at most 50 characters long'),

    body('password')
        .notEmpty()
        .withMessage('Password is required')
        .isLength({ min: 6 })
        .withMessage('Password must be at least 6 characters long'),

    body('creation_date')
        .optional()
        .isDate()
        .withMessage('Creation date must be a valid date'),

    body('sale_detail_id')
        .optional()
        .isInt()
        .withMessage('Sale detail ID must be an integer'),

    body('roles_id')
        .optional()
        .isInt()
        .withMessage('Role ID must be an integer'),

    body('employee_id')
        .optional()
        .isInt()
        .withMessage('Employee ID must be an integer'),

    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    },
];

// Validación para Product
const validateProduct = [
    body('name')
        .notEmpty()
        .withMessage('Name is required')
        .isLength({ max: 50 })
        .withMessage('Name must be at most 50 characters long'),

    body('price')
        .notEmpty()
        .withMessage('Price is required')
        .isDecimal({ decimal_digits: '2' })
        .withMessage('Price must be a decimal number with two decimal places'),

    body('stock')
        .notEmpty()
        .withMessage('Stock is required')
        .isInt()
        .withMessage('Stock must be an integer'),

    body('expiration_date')
        .optional() // Puede ser opcional si no es obligatorio en tu base de datos
        .isDate()
        .withMessage('Expiration date must be a valid date'),

    body('id_category')
        .optional()
        .isInt()
        .withMessage('Category ID must be an integer'),

    body('max_capacity')
        .optional()
        .isInt()
        .withMessage('Max capacity must be an integer'),

    body('min_capacity')
        .optional()
        .isInt()
        .withMessage('Min capacity must be an integer'),

    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    },
];

// Validación para Order
const validateOrder = [
    body('address')
        .notEmpty()
        .withMessage('Address is required')
        .isLength({ max: 150 })
        .withMessage('Address must be at most 150 characters long'),

    body('order_date')
        .notEmpty()
        .withMessage('Order date is required')
        .isDate()
        .withMessage('Order date must be a valid date'),

    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }
        next();
    },
];

// Validación para búsqueda
function validateSearch(req, res, next) {
    const searchTerm = req.query.q; 
    if (!searchTerm) {
        return res.status(400).json({ message: "Search term is required." });
    }
    next();
}

module.exports = { 
    validateCategory, 
    validateRoles, 
    validateRolesDesign, 
    validateEmployee, 
    validateUser, 
    validateProduct, 
    validateOrder,  // Agregado aquí
    validateSearch 
};
