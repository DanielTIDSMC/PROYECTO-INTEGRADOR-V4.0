const Employee = require("../models/employeeModel");
const XLSX = require("xlsx");

class EmployeeController {
    // Obtener todos los empleados
    static async getAllEmployees(req, res) {
        try {
            const employees = await Employee.findAll();
            res.json(employees);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    // Obtener un empleado por su ID
    static async getEmployeeById(req, res) {
        try {
            const employee = await Employee.findById(req.params.id);

            if (!employee) {
                return res.status(404).json({ message: "Employee not found" });
            }

            res.json(employee);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    // Crear un nuevo empleado
    static async createEmployee(req, res) {
        try {
            const { name, paternal_surname, maternal_surname, hire_date, birth_date } = req.body;
            const employee = await Employee.create({ name, paternal_surname, maternal_surname, hire_date, birth_date });

            res.status(201).json(employee);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    // Actualizar un empleado por su ID
    static async updateEmployee(req, res) {
        try {
            const { name, paternal_surname, maternal_surname, hire_date, birth_date } = req.body;
            const employee = await Employee.update(req.params.id, { name, paternal_surname, maternal_surname, hire_date, birth_date });

            if (!employee) {
                return res.status(404).json({ message: "Employee not found" });
            }

            res.json(employee);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    // Eliminar un empleado por su ID
    static async deleteEmployee(req, res) {
        try {
            const result = await Employee.delete(req.params.id);

            res.json(result);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    // Buscar empleados por término de búsqueda
    static async searchEmployee(req, res) {
        const searchTerm = req.query.q;

        if (!searchTerm) {
            return res.status(400).json({ message: "Search term is required." });
        }

        try {
            const employees = await Employee.search(searchTerm);
            res.json(employees);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    // Descargar empleados en formato Excel
    static async downloadEmployeesExcel(req, res) {
        try {
            const employees = await Employee.findAll();

            if (!employees || employees.length === 0) {
                return res.status(404).json({ message: "No employees found." });
            }

            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(employees);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Employees");

            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            res.setHeader("Content-Disposition", "attachment; filename=employees.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);
        } catch (error) {
            console.error("Error generating Excel file:", error);
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = EmployeeController;
