/**
 * @swagger
 * components:
 *   schemas:
 *     product:
 *       type: object
 *       required:
 *         - name
 *         - price
 *         - stock
 *         - created_at
 *         - updated_at
 *       properties:
 *         id_product:
 *           type: integer
 *           description: ID único del producto
 *         name:
 *           type: string
 *           description: Nombre del producto
 *         price:
 *           type: number
 *           format: decimal
 *           description: Precio del producto con dos decimales
 *         stock:
 *           type: integer
 *           description: Cantidad disponible del producto en stock
 *         expiration_date:
 *           type: string
 *           format: date
 *           description: Fecha de expiración del producto
 *         id_category:
 *           type: integer
 *           description: ID de la categoría del producto (referencia a category)
 *         max_capacity:
 *           type: integer
 *           description: Capacidad máxima del producto
 *         min_capacity:
 *           type: integer
 *           description: Capacidad mínima del producto
 *         created_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de creación del producto
 *         updated_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de la última actualización del producto
 *       example:
 *         id_product: 1
 *         name: Producto A
 *         price: 99.99
 *         stock: 100
 *         expiration_date: '2024-12-31'
 *         id_category: 2
 *         max_capacity: 200
 *         min_capacity: 50
 *         created_at: '2024-01-01T10:00:00Z'
 *         updated_at: '2024-01-02T10:00:00Z'
 */

/**
 * @swagger
 * /api/products:
 *   post:
 *     summary: Registra un nuevo producto
 *     tags: [Products]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre del producto
 *               price:
 *                 type: number
 *                 format: decimal
 *                 description: Precio del producto (con dos decimales)
 *               stock:
 *                 type: integer
 *                 description: Cantidad disponible en stock
 *               expiration_date:
 *                 type: string
 *                 format: date
 *                 description: Fecha de expiración del producto (opcional)
 *               id_category:
 *                 type: integer
 *                 description: ID de la categoría del producto (opcional)
 *               max_capacity:
 *                 type: integer
 *                 description: Capacidad máxima del producto (opcional)
 *               min_capacity:
 *                 type: integer
 *                 description: Capacidad mínima del producto (opcional)
 *     responses:
 *       201:
 *         description: Producto creado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/product'
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/products/{id_product}:
 *   get:
 *     summary: Obtiene un producto por su ID
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: id_product
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del producto a obtener
 *     responses:
 *       200:
 *         description: Producto encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/product'
 *       404:
 *         description: Producto no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/products/{id_product}:
 *   put:
 *     summary: Actualiza un producto por su ID
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: id_product
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del producto a actualizar
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/product'
 *     responses:
 *       200:
 *         description: Producto actualizado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/product'
 *       404:
 *         description: Producto no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/products/{id_product}:
 *   delete:
 *     summary: Elimina un producto por su ID
 *     tags: [Products]
 *     parameters:
 *       - in: path
 *         name: id_product
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del producto a eliminar
 *     responses:
 *       200:
 *         description: Producto eliminado con éxito
 *       404:
 *         description: Producto no encontrado
 *       500:
 *         description: Error en el servidor
 */

const express = require("express");
const ProductController = require("../controllers/productController");
const { validateProduct } = require("../middlewares/validation");
const router = express.Router();

router.post("/", validateProduct, ProductController.createProduct);
router.get("/", ProductController.getAllProducts);
router.get("/:id", ProductController.getProductById);
router.put("/:id", validateProduct, ProductController.updateProduct);
router.delete("/:id", ProductController.deleteProduct);

module.exports = router;
