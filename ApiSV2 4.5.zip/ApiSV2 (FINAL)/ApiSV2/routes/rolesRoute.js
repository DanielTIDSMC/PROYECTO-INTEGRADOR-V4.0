/**
 * @swagger
 * components:
 *   schemas:
 *     role:
 *       type: object
 *       required:
 *         - namerols
 *       properties:
 *         roles_id:
 *           type: integer
 *           description: ID único del rol
 *         namerols:
 *           type: string
 *           description: Nombre del rol
 *         created_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de creación del rol
 *         updated_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de la última actualización del rol
 *       example:
 *         roles_id: 1
 *         namerols: Administrador
 *         created_at: '2024-01-01T10:00:00Z'
 *         updated_at: '2024-01-02T10:00:00Z'
 */

/**
 * @swagger
 * /api/roles:
 *   post:
 *     summary: Registra un nuevo rol
 *     tags: [Roles]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               namerols:
 *                 type: string
 *                 description: Nombre del rol
 *     responses:
 *       201:
 *         description: Rol creado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/role'
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/roles/{roles_id}:
 *   get:
 *     summary: Obtiene un rol por su ID
 *     tags: [Roles]
 *     parameters:
 *       - in: path
 *         name: roles_id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del rol a obtener
 *     responses:
 *       200:
 *         description: Rol encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/role'
 *       404:
 *         description: Rol no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/roles/{roles_id}:
 *   put:
 *     summary: Actualiza un rol por su ID
 *     tags: [Roles]
 *     parameters:
 *       - in: path
 *         name: roles_id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del rol a actualizar
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               namerols:
 *                 type: string
 *                 description: Nombre del rol
 *     responses:
 *       200:
 *         description: Rol actualizado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/role'
 *       404:
 *         description: Rol no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/roles/{roles_id}:
 *   delete:
 *     summary: Elimina un rol por su ID
 *     tags: [Roles]
 *     parameters:
 *       - in: path
 *         name: roles_id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del rol a eliminar
 *     responses:
 *       200:
 *         description: Rol eliminado con éxito
 *       404:
 *         description: Rol no encontrado
 *       500:
 *         description: Error en el servidor
 */

const express = require("express");
const RolesController = require("../controllers/rolesController");
const { validateRoles, validateSearch } = require("../middlewares/validation");

const router = express.Router();

// Rutas para roles
router.get("/", RolesController.getAllRoles);
router.get("/:id", RolesController.getRoleById);
router.post("/", validateRoles, RolesController.createRole);
router.put("/:id", validateRoles, RolesController.updateRole);
router.delete("/:id", RolesController.deleteRole);
router.get("/download/excel", RolesController.downloadRolesExcel);

module.exports = router;


