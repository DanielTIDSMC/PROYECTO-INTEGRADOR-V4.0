/**
 * @swagger
 * components:
 *   schemas:
 *     user:
 *       type: object
 *       required:
 *         - name
 *         - password
 *       properties:
 *         id_user:
 *           type: integer
 *           description: ID único del usuario
 *         name:
 *           type: string
 *           description: Nombre del usuario
 *         password:
 *           type: string
 *           description: Contraseña del usuario
 *         creation_date:
 *           type: string
 *           format: date
 *           description: Fecha de creación del usuario
 *         roles_id:
 *           type: integer
 *           description: ID del rol asignado al usuario
 *         employee_id:
 *           type: integer
 *           description: ID del empleado asociado al usuario
 *         created_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de creación del registro
 *         updated_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de la última actualización del registro
 *       example:
 *         id_user: 1
 *         name: Juan
 *         password: 12345
 *         creation_date: '2024-01-01'
 *         roles_id: 2
 *         employee_id: 5
 *         created_at: '2024-01-01T10:00:00Z'
 *         updated_at: '2024-01-02T10:00:00Z'
 */

/**
 * @swagger
 * /api/users:
 *   post:
 *     summary: Registra un nuevo usuario
 *     tags: [Users]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre del usuario
 *               password:
 *                 type: string
 *                 description: Contraseña del usuario
 *               creation_date:
 *                 type: string
 *                 format: date
 *                 description: Fecha de creación del usuario
 *               roles_id:
 *                 type: integer
 *                 description: ID del rol asignado
 *               employee_id:
 *                 type: integer
 *                 description: ID del empleado asociado al usuario
 *     responses:
 *       201:
 *         description: Usuario creado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/user'
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/users/{id_user}:
 *   get:
 *     summary: Obtiene un usuario por su ID
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id_user
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del usuario a obtener
 *     responses:
 *       200:
 *         description: Usuario encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/user'
 *       404:
 *         description: Usuario no encontrado
 *       500:
 *         description: Error en el servidor
 */
/**
 * @swagger
 * /api/users/{id_user}:
 *   put:
 *     summary: Actualiza un usuario existente
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id_user
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del usuario a actualizar
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre del usuario
 *               password:
 *                 type: string
 *                 description: Contraseña del usuario
 *               creation_date:
 *                 type: string
 *                 format: date
 *                 description: Fecha de creación del usuario
 *               roles_id:
 *                 type: integer
 *                 description: ID del rol asignado
 *               employee_id:
 *                 type: integer
 *                 description: ID del empleado asociado al usuario
 *     responses:
 *       200:
 *         description: Usuario actualizado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/user'
 *       404:
 *         description: Usuario no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/users/{id_user}:
 *   delete:
 *     summary: Elimina un usuario existente
 *     tags: [Users]
 *     parameters:
 *       - in: path
 *         name: id_user
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del usuario a eliminar
 *     responses:
 *       200:
 *         description: Usuario eliminado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   description: Mensaje de confirmación
 *               example:
 *                 message: Usuario eliminado exitosamente
 *       404:
 *         description: Usuario no encontrado
 *       500:
 *         description: Error en el servidor
 */

const express = require("express");
const UserController = require("../controllers/userController");
const router = express.Router();

router.get("/", UserController.getAllUsers);
router.get("/:id_user", UserController.getUserById); 
router.post("/", UserController.createUser); 
router.put("/:id_user", UserController.updateUser); 
router.delete("/:id_user", UserController.deleteUser); 

module.exports = router;


