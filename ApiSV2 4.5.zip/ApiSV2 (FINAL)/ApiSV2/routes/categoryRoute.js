/**
 * @swagger
 * components:
 *   schemas:
 *     category:
 *       type: object
 *       required:
 *         - id
 *         - name 
 *       properties:
 *         id:
 *           type: integer
 *           description: ID único de la categoria
 *         name:
 *           type: string
 *           description: Nombre de la categoria 
 *       example:
 *         id: 1
 *         name: Electronica
 */

/**
 * @swagger
 * /api/categories:
 *   post:
 *     summary: Registra una categoria
 *     tags: [Category]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre de la categoria
 *     responses:
 *       201:
 *         description: La categoria ha sido creada con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/category'
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/categories/{id}:
 *   get:
 *     summary: Obtiene una categoria por su ID
 *     tags: [Category]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID de la categoria
 *     responses:
 *       200:
 *         description: Categoria encontrada
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/category'
 *       404:
 *         description: Categoria no encontrada
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/categories/{id}:
 *   put:
 *     summary: Actualiza una categoría por su ID
 *     tags: [Category]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID de la categoría
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre de la categoría
 *     responses:
 *       200:
 *         description: Categoría actualizada con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/category'
 *       404:
 *         description: Categoría no encontrada
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/categories/{id}:
 *   delete:
 *     summary: Elimina una categoría por su ID
 *     tags: [Category]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID de la categoría
 *     responses:
 *       200:
 *         description: Categoría eliminada con éxito
 *       404:
 *         description: Categoría no encontrada
 *       500:
 *         description: Error en el servidor
 */

const express = require("express");
const CategoryController = require("../controllers/categoryController");
const { validateCategory } = require("../middlewares/validation");
const router = express.Router();

// Definir las rutas
router.get("/", CategoryController.getAllCategories);
router.get("/:id", CategoryController.getCategoryById);
router.post("/", validateCategory, CategoryController.createCategory);
router.put("/:id", validateCategory, CategoryController.updateCategory);
router.delete("/:id", CategoryController.deleteCategory);

module.exports = router;







