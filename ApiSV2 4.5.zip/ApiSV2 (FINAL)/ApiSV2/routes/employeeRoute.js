/**
 * @swagger
 * components:
 *   schemas:
 *     employee:
 *       type: object
 *       required:
 *         - name
 *         - paternal_surname
 *         - maternal_surname
 *         - hire_date
 *         - birth_date
 *       properties:
 *         id:
 *           type: integer
 *           description: ID único del empleado
 *         name:
 *           type: string
 *           description: Nombre del empleado
 *         paternal_surname:
 *           type: string
 *           description: Apellido paterno del empleado
 *         maternal_surname:
 *           type: string
 *           description: Apellido paterno del empleado
 *         hire_date:
 *           type: date
 *           description: Fecha de contratacion del empleado
 *         birth_date:
 *           type: date
 *           description: Fecha de nacimiento del empleado
 *       example:
 *         id: 1
 *         name: Juan
 *         paternal_surname: Herrera
 *         maternal_surname: Cobos
 *         hire_date: "2024-11-24"
 *         birth_date: "2004-10-01"
 */
/**
 * @swagger
 * /api/employees:
 *   post:
 *     summary: Registra un nuevo empleado
 *     tags: [Employee]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre del empleado
 *               paternal_surname:
 *                 type: string
 *                 description: Apellido paterno del empleado
 *               maternal_surname:
 *                 type: string
 *                 description: Apellido materno del empleado
 *               hire_date:
 *                 type: date
 *                 description: Fecha de contratación del empleado
 *               birth_date:
 *                 type: date
 *                 description: Fecha de nacimiento del empleado
 *     responses:
 *       201:
 *         description: El empleado ha sido creado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/employee'
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/employees/{id}:
 *   get:
 *     summary: Obtiene un empleado por su ID
 *     tags: [Employee]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del empleado
 *     responses:
 *       200:
 *         description: Empleado encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/employee'
 *       404:
 *         description: Empleado no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/employees/{id}:
 *   put:
 *     summary: Actualiza un empleado por su ID
 *     tags: [Employee]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del empleado
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre del empleado
 *               paternal_surname:
 *                 type: string
 *                 description: Apellido paterno del empleado
 *               maternal_surname:
 *                 type: string
 *                 description: Apellido materno del empleado
 *               hire_date:
 *                 type: date
 *                 description: Fecha de contratación del empleado
 *               birth_date:
 *                 type: date
 *                 description: Fecha de nacimiento del empleado
 *     responses:
 *       200:
 *         description: Empleado actualizado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/employee'
 *       404:
 *         description: Empleado no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/employees/{id}:
 *   delete:
 *     summary: Elimina un empleado por su ID
 *     tags: [Employee]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del empleado
 *     responses:
 *       200:
 *         description: Empleado eliminado con éxito
 *       404:
 *         description: Empleado no encontrado
 *       500:
 *         description: Error en el servidor
 */

const express = require('express');
const EmployeeController = require('../controllers/employeeController');
const { validateEmployee } = require('../middlewares/validation');
const router = express.Router();

router.get('/', EmployeeController.getAllEmployees);  // Cambié de '/employees' a '/'
router.get('/:id', EmployeeController.getEmployeeById); // Esto es correcto
router.post('/', validateEmployee, EmployeeController.createEmployee);  // Cambié de '/employees' a '/'
router.put('/:id', validateEmployee, EmployeeController.updateEmployee);  // Esto es correcto
router.delete('/:id', EmployeeController.deleteEmployee);  // Esto es correcto
router.get('/download', EmployeeController.downloadEmployeesExcel);  // Esto es correcto

module.exports = router;

