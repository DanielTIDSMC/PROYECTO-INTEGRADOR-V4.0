const express = require("express");
const categoryRoute = require("./routes/categoryRoute");
const rolesRoute = require("./routes/rolesRoute");
const userRoute = require("./routes/userRoute");
const productRoute = require("./routes/productRoute");
const positionRoute = require("./routes/positionRoute");
const supplierRoute = require("./routes/supplierRoute");
const employeeRoute = require("./routes/employeeRoute");
const swaggerDocs = require("./config/swagger");

require("dotenv").config();

const app = express();
swaggerDocs(app);

// Middleware para registrar las solicitudes en el servidor
app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
    next();
});

// Middleware para manejar datos JSON
app.use(express.json());

// Rutas del servidor
app.use("/api/categories", categoryRoute);
app.use("/api/roles", rolesRoute);
app.use("/api/users", userRoute);
app.use("/api/products", productRoute);
app.use("/api/positions", positionRoute);
app.use("/api/suppliers", supplierRoute); // Ruta de proveedores
app.use("/api/employees", employeeRoute);

// Puerto del servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`SERVER IS RUNNING ON PORT: ${PORT}`);
});
