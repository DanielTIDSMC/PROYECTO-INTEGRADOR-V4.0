const { body, validationResult } = require("express-validator");

// Middleware para manejar errores de validación
const handleValidationErrors = (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    next();
};

// Validación para Category
const validateCategory = [
    body("name")
        .notEmpty()
        .withMessage("Name is required")
        .isLength({ max: 100 })
        .withMessage("Name must be at most 100 characters long"),
    handleValidationErrors,
];

// Validación para Position
const validatePosition = [
    body("position_name")
        .notEmpty()
        .withMessage("Position name is required")
        .isLength({ max: 50 })
        .withMessage("Position name must be at most 50 characters long"),
    body("salary")
        .notEmpty()
        .withMessage("Salary is required")
        .isDecimal({ decimal_digits: "0" })
        .withMessage("Salary must be a valid decimal number without decimals"),
    body("employee_id")
        .notEmpty()
        .withMessage("Employee ID is required")
        .isInt()
        .withMessage("Employee ID must be an integer"),
    handleValidationErrors,
];

// Validación para Product
const validateProduct = [
    body("name")
        .notEmpty()
        .withMessage("Name is required")
        .isLength({ max: 50 })
        .withMessage("Name must be at most 50 characters long"),
    body("price")
        .notEmpty()
        .withMessage("Price is required")
        .isDecimal({ decimal_digits: "2" })
        .withMessage("Price must be a decimal number with two decimal places"),
    body("stock")
        .notEmpty()
        .withMessage("Stock is required")
        .isInt()
        .withMessage("Stock must be an integer"),
    body("expiration_date")
        .optional()
        .isDate()
        .withMessage("Expiration date must be a valid date"),
    body("id_category")
        .optional()
        .isInt()
        .withMessage("Category ID must be an integer"),
];

// Validación para Roles
const validateRoles = [
    body("namerols")
        .notEmpty()
        .withMessage("Role name is required")
        .isLength({ max: 50 })
        .withMessage("Role name must be at most 50 characters long"),
    handleValidationErrors,
];

// Validación para Supplier
const validateSupplier = [
    body("name")
        .notEmpty()
        .withMessage("Name is required")
        .isLength({ max: 50 })
        .withMessage("Name must be at most 50 characters long"),
    body("company_address")
        .notEmpty()
        .withMessage("Company address is required")
        .isLength({ max: 100 })
        .withMessage("Company address must be at most 100 characters long"),
    body("phone")
        .notEmpty()
        .withMessage("Phone is required")
        .isLength({ min: 10, max: 15 })
        .withMessage("Phone must be between 10 and 15 characters long"),
    body("email")
        .notEmpty()
        .withMessage("Email is required")
        .isEmail()
        .withMessage("Email must be a valid email address")
        .isLength({ max: 50 })
        .withMessage("Email must be at most 50 characters long"),
    body("contact_info")
        .notEmpty()
        .withMessage("Contact info is required")
        .isLength({ max: 200 })
        .withMessage("Contact info must be at most 200 characters long"),
    handleValidationErrors,
];


// Validación para Employee
const validateEmployee = [
    body("name")
        .notEmpty()
        .withMessage("Name is required")
        .isLength({ max: 50 })
        .withMessage("Name must be at most 50 characters long"),
    body("paternal_surname")
        .notEmpty()
        .withMessage("Paternal surname is required")
        .isLength({ max: 50 })
        .withMessage("Paternal surname must be at most 50 characters long"),
    body("maternal_surname")
        .optional()
        .isLength({ max: 50 })
        .withMessage("Maternal surname must be at most 50 characters long"),
    body("hire_date")
        .notEmpty()
        .withMessage("Hire date is required")
        .isDate()
        .withMessage("Hire date must be a valid date"),
    body("birth_date")
        .notEmpty()
        .withMessage("Birth date is required")
        .isDate()
        .withMessage("Birth date must be a valid date"),
    handleValidationErrors,
];

// Validación para User
const validateUser = [
    body("name")
        .notEmpty()
        .withMessage("Name is required")
        .isLength({ max: 50 })
        .withMessage("Name must be at most 50 characters long"),
    body("password")
        .notEmpty()
        .withMessage("Password is required")
        .isLength({ min: 6 })
        .withMessage("Password must be at least 6 characters long"),
    body("creation_date")
        .optional()
        .isDate()
        .withMessage("Creation date must be a valid date"),
    body("roles_id")
        .optional()
        .isInt()
        .withMessage("Role ID must be an integer"),
    body("employee_id")
        .optional()
        .isInt()
        .withMessage("Employee ID must be an integer"),
    handleValidationErrors,
];

module.exports = {
    validateCategory,
    validatePosition,
    validateProduct,
    validateRoles,
    validateSupplier,
    validateEmployee,
    validateUser
};
