const pool = require("../config/db");

class Roles {
    static async findAll(filters = {}) {
        const { namerols } = filters;
        let query = "SELECT * FROM roles WHERE 1=1";
        const queryParams = [];

        if (namerols) {
            queryParams.push(`%${namerols}%`);
            query += ` AND namerols ILIKE $${queryParams.length}`;
        }

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    static async findOne(id) {
        const query = "SELECT * FROM roles WHERE roles_id = $1";
        const result = await pool.query(query, [id]);
        return result.rows[0];
    }

    static async create(data) {
        const { namerols } = data;
        const result = await pool.query(
            "INSERT INTO roles (namerols) VALUES ($1) RETURNING *",
            [namerols]
        );
        return result.rows[0];
    }

    static async update(id, data) {
        const { namerols } = data;
        const result = await pool.query(
            "UPDATE roles SET namerols = $1, updated_at = CURRENT_TIMESTAMP WHERE roles_id = $2 RETURNING *",
            [namerols, id]
        );
        return result.rows[0];
    }

    static async delete(id) {
        await pool.query("DELETE FROM roles WHERE roles_id = $1", [id]);
        return { message: "Role deleted successfully" };
    }

    static async search(searchTerm) {
        const query = `
            SELECT * FROM roles 
            WHERE namerols ILIKE $1
        `;
        const result = await pool.query(query, [`%${searchTerm}%`]);
        return result.rows;
    }
}

module.exports = Roles;
