const pool = require('../config/db');

class Category {
    static async findAll(filters = {}) {
        const { name } = filters;
        let query = 'SELECT * FROM category WHERE 1=1';
        const queryParams = [];

        if (name) {
            queryParams.push(`%${name}%`);
            query += ` AND name ILIKE $${queryParams.length}`;
        }

        const result = await pool.query(query, queryParams);
        return result.rows;
    }

    static async findById(id) {
        const result = await pool.query('SELECT * FROM category WHERE id_category = $1', [id]);
        return result.rows[0] || null;
    }

    static async create(data) {
        const { name } = data;
        const result = await pool.query('INSERT INTO category (name) VALUES ($1) RETURNING *', [name]);
        return result.rows[0];
    }

    static async update(id, data) {
        const { name } = data;
        const result = await pool.query(
            'UPDATE category SET name = $1, updated_at = CURRENT_TIMESTAMP WHERE id_category = $2 RETURNING *',
            [name, id]
        );
        return result.rows[0] || null;
    }

    static async delete(id) {
        const result = await pool.query('DELETE FROM category WHERE id_category = $1 RETURNING *', [id]);
        return result.rowCount > 0; // Retorna true si se eliminó algo
    }
}

module.exports = Category;
