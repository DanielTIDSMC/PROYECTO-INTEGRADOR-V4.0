const pool = require("../config/db");

class Position {
    static async findAll() {
        const result = await pool.query("SELECT * FROM positions");
        return result.rows;
    }

    static async findById(id) {
        const result = await pool.query("SELECT * FROM positions WHERE id_position = $1", [id]);
        return result.rows.length ? result.rows[0] : null;
    }

    static async create(data) {
        const { position_name, salary, employee_id } = data;
        const result = await pool.query(
            "INSERT INTO positions (position_name, salary, employee_id) VALUES ($1, $2, $3) RETURNING *",
            [position_name, salary, employee_id]
        );
        return result.rows[0];
    }

    static async update(id, data) {
        const { position_name, salary, employee_id } = data;
        const result = await pool.query(
            "UPDATE positions SET position_name = $1, salary = $2, employee_id = $3, updated_at = CURRENT_TIMESTAMP WHERE id_position = $4 RETURNING *",
            [position_name, salary, employee_id, id]
        );
        return result.rows.length ? result.rows[0] : null;
    }

    static async delete(id) {
        const result = await pool.query("DELETE FROM positions WHERE id_position = $1 RETURNING *", [id]);
        if (result.rowCount === 0) {
            throw new Error("Position not found");
        }
        return { message: "Position deleted successfully" };
    }
}

module.exports = Position;
