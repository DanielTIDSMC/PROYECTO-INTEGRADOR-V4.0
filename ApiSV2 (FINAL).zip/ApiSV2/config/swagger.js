    const swaggerJsdoc = require('swagger-jsdoc');
    const swaggerUi = require('swagger-ui-express');
    const { version } = require('xlsx');
    require('dotenv').config();

    const options = {
        definition: {
            openapi: '3.0.0',
            info: {
                title: 'API de proyecto',
                version: '1.0.0',
                description: 'Documentacion de API de proyecto'
            },
            servers: [
                {
                    url: 'http://localhost:' + process.env.APP_PORT,
                },
            ],
        },
        apis: ['./routes/*.js'],
    };

    const swaggerSpec = swaggerJsdoc(options);
    const swaggerDocs = (app) => {
        app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));
        console.log('Swagger docs available at http:localhost:' + process.env.APP_PORT + '/api-docs');
    };

    module.exports = swaggerDocs;