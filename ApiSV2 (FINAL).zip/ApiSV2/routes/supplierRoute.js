/**
 * @swagger
 * components:
 *   schemas:
 *     supplier:
 *       type: object
 *       required:
 *         - name
 *         - company_address
 *         - phone
 *         - email
 *         - contact_info
 *       properties:
 *         id_supplier:
 *           type: integer
 *           description: ID único del proveedor
 *         name:
 *           type: string
 *           description: Nombre del proveedor
 *         company_address:
 *           type: string
 *           description: Dirección de la compañía del proveedor
 *         phone:
 *           type: string
 *           description: Número de teléfono del proveedor
 *         email:
 *           type: string
 *           description: Correo electrónico del proveedor
 *         contact_info:
 *           type: string
 *           description: Información de contacto adicional del proveedor
 *         created_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de creación del proveedor
 *         updated_at:
 *           type: string
 *           format: date-time
 *           description: Fecha de la última actualización del proveedor
 *       example:
 *         id_supplier: 1
 *         name: Proveedor A
 *         company_address: Calle 123, Ciudad
 *         phone: '1234567890'
 *         email: proveedor@example.com
 *         contact_info: "Contacto principal: Juan Pérez"
 *         created_at: '2024-01-01T10:00:00Z'
 *         updated_at: '2024-01-02T10:00:00Z'
 */

/**
 * @swagger
 * /api/suppliers:
 *   post:
 *     summary: Registra un nuevo proveedor
 *     tags: [Suppliers]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre del proveedor
 *               company_address:
 *                 type: string
 *                 description: Dirección de la compañía
 *               phone:
 *                 type: string
 *                 description: Número de teléfono del proveedor
 *               email:
 *                 type: string
 *                 description: Correo electrónico del proveedor
 *               contact_info:
 *                 type: string
 *                 description: Información de contacto adicional
 *     responses:
 *       201:
 *         description: Proveedor creado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/supplier'
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/suppliers/{id_supplier}:
 *   get:
 *     summary: Obtiene un proveedor por su ID
 *     tags: [Suppliers]
 *     parameters:
 *       - in: path
 *         name: id_supplier
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del proveedor a obtener
 *     responses:
 *       200:
 *         description: Proveedor encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/supplier'
 *       404:
 *         description: Proveedor no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/suppliers/{id_supplier}:
 *   put:
 *     summary: Actualiza un proveedor por su ID
 *     tags: [Suppliers]
 *     parameters:
 *       - in: path
 *         name: id_supplier
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del proveedor a actualizar
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 description: Nombre del proveedor
 *               company_address:
 *                 type: string
 *                 description: Dirección de la compañía
 *               phone:
 *                 type: string
 *                 description: Número de teléfono del proveedor
 *               email:
 *                 type: string
 *                 description: Correo electrónico del proveedor
 *               contact_info:
 *                 type: string
 *                 description: Información de contacto adicional
 *     responses:
 *       200:
 *         description: Proveedor actualizado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/supplier'
 *       404:
 *         description: Proveedor no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/suppliers/{id_supplier}:
 *   delete:
 *     summary: Elimina un proveedor por su ID
 *     tags: [Suppliers]
 *     parameters:
 *       - in: path
 *         name: id_supplier
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del proveedor a eliminar
 *     responses:
 *       200:
 *         description: Proveedor eliminado con éxito
 *       404:
 *         description: Proveedor no encontrado
 *       500:
 *         description: Error en el servidor
 */

const express = require("express");
const SupplierController = require("../controllers/supplierController");
// const { validateSupplier } = require("../middlewares/validation"); // Comentar temporalmente

const router = express.Router();

// Cambios: Elimina `/suppliers` duplicado en las rutas
router.get("/", SupplierController.getAllSuppliers);
router.get("/:id", SupplierController.getSupplierById);
router.post("/", SupplierController.createSupplier); // Comentado el middleware
router.put("/:id", SupplierController.updateSupplier);
router.delete("/:id", SupplierController.deleteSupplier);
router.get("/excel", SupplierController.downloadSuppliersExcel);

module.exports = router;



