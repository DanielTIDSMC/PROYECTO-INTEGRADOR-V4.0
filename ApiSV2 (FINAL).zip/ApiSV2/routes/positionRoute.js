/**
 * @swagger
 * components:
 *   schemas:
 *     position:
 *       type: object
 *       required:
 *         - position_name
 *         - salary 
 *         - employee_id
 *       properties:
 *         id:
 *           type: integer
 *           description: ID único del puesto
 *         position_name:
 *           type: string
 *           description: Nombre del puesto
 *         salary:
 *           type: float
 *           description: Salario del puesto 
 *         employee_id:
 *           type: integer
 *           description: ID del empleado asociado al puesto
 *       example:
 *         id: 1
 *         position_name: Gerente
 *         salary: 1234.56
 *         employee_id: 123
 */

/**
 * @swagger
 * /api/positions:
 *   post:
 *     summary: Registra un nuevo puesto
 *     tags: [Position]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               position_name:
 *                 type: string
 *                 description: Nombre del puesto
 *               salary:
 *                 type: float
 *                 description: Salario del puesto
 *               employee_id:
 *                 type: integer
 *                 description: ID del empleado asociado al puesto
 *     responses:
 *       201:
 *         description: Puesto creado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/position'
 *       400:
 *         description: Error de validación, los campos requeridos son incorrectos
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/positions/{id}:
 *   get:
 *     summary: Obtiene un puesto por su ID
 *     tags: [Position]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del puesto
 *     responses:
 *       200:
 *         description: Puesto encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/position'
 *       404:
 *         description: Puesto no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/positions/{id}:
 *   put:
 *     summary: Actualiza un puesto por su ID
 *     tags: [Position]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del puesto
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               position_name:
 *                 type: string
 *                 description: Nombre del puesto
 *               salary:
 *                 type: float
 *                 description: Salario del puesto
 *               employee_id:
 *                 type: integer
 *                 description: ID del empleado asociado al puesto
 *     responses:
 *       200:
 *         description: Puesto actualizado con éxito
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/position'
 *       404:
 *         description: Puesto no encontrado
 *       500:
 *         description: Error en el servidor
 */

/**
 * @swagger
 * /api/positions/{id}:
 *   delete:
 *     summary: Elimina un puesto por su ID
 *     tags: [Position]
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: integer
 *         required: true
 *         description: ID del puesto
 *     responses:
 *       200:
 *         description: Puesto eliminado con éxito
 *       404:
 *         description: Puesto no encontrado
 *       500:
 *         description: Error en el servidor
 */

const express = require("express");
const PositionController = require("../controllers/positionController");
const { validatePosition } = require("../middlewares/validation");

const router = express.Router();

router.get("/", PositionController.getAllPositions);
router.get("/:id", PositionController.getPositionById);
router.post("/", validatePosition, PositionController.createPosition);
router.put("/:id", validatePosition, PositionController.updatePosition);
router.delete("/:id", PositionController.deletePosition);

module.exports = router;
