const Supplier = require("../models/supplierModel");
const XLSX = require("xlsx");

class SupplierController {
    static async getAllSuppliers(req, res) {
        try {
            const suppliers = await Supplier.findAll();
            res.json(suppliers);
        } catch (error) {
            console.error("Error fetching suppliers:", error);
            res.status(500).json({ error: error.message });
        }
    }

    static async getSupplierById(req, res) {
        try {
            const supplier = await Supplier.findById(req.params.id);

            if (!supplier) {
                return res.status(404).json({ message: "Supplier not found" });
            }

            res.json(supplier);
        } catch (error) {
            console.error("Error fetching supplier by ID:", error);
            res.status(500).json({ error: error.message });
        }
    }

    static async createSupplier(req, res) {
        try {
            console.log("Request body:", req.body); // Log para verificar los datos
            const supplier = await Supplier.create(req.body);
            res.status(201).json(supplier);
        } catch (error) {
            console.error("Error creating supplier:", error);
            res.status(500).json({ error: error.message });
        }
    }

    static async updateSupplier(req, res) {
        try {
            const supplier = await Supplier.update(req.params.id, req.body);

            if (!supplier) {
                return res.status(404).json({ message: "Supplier not found" });
            }

            res.json(supplier);
        } catch (error) {
            console.error("Error updating supplier:", error);
            res.status(500).json({ error: error.message });
        }
    }

    static async deleteSupplier(req, res) {
        try {
            const result = await Supplier.delete(req.params.id);
            res.json(result);
        } catch (error) {
            console.error("Error deleting supplier:", error);
            res.status(500).json({ error: error.message });
        }
    }

    static async downloadSuppliersExcel(req, res) {
        try {
            const suppliers = await Supplier.findAll();

            if (!suppliers || suppliers.length === 0) {
                return res.status(404).json({ message: "No suppliers found." });
            }

            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(suppliers);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Suppliers");

            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            res.setHeader("Content-Disposition", "attachment; filename=suppliers.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);
        } catch (error) {
            console.error("Error generating Excel file:", error);
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = SupplierController;
