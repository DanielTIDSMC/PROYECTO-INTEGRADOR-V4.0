const Roles = require("../models/rolesModel");
const XLSX = require("xlsx");

class RolesController {
    static async getAllRoles(req, res) {
        try {
            const roles = await Roles.findAll(req.query);
            res.json(roles);
        } catch (error) {
            console.error("Error fetching roles:", error);
            res.status(500).json({ error: "Failed to fetch roles" });
        }
    }

    static async getRoleById(req, res) {
        try {
            const role = await Roles.findOne(req.params.id);

            if (!role) {
                return res.status(404).json({ message: "Role not found" });
            }

            res.json(role);
        } catch (error) {
            console.error("Error fetching role:", error);
            res.status(500).json({ error: "Failed to fetch role" });
        }
    }

    static async createRole(req, res) {
        try {
            const role = await Roles.create(req.body);
            res.status(201).json(role);
        } catch (error) {
            console.error("Error creating role:", error);
            res.status(500).json({ error: "Failed to create role" });
        }
    }

    static async updateRole(req, res) {
        try {
            const role = await Roles.update(req.params.id, req.body);

            if (!role) {
                return res.status(404).json({ message: "Role not found" });
            }

            res.json(role);
        } catch (error) {
            console.error("Error updating role:", error);
            res.status(500).json({ error: "Failed to update role" });
        }
    }

    static async deleteRole(req, res) {
        try {
            await Roles.delete(req.params.id);
            res.json({ message: "Role deleted successfully" });
        } catch (error) {
            console.error("Error deleting role:", error);
            res.status(500).json({ error: "Failed to delete role" });
        }
    }

    static async searchRoles(req, res) {
        const searchTerm = req.query.q;

        if (!searchTerm) {
            return res.status(400).json({ message: "Search term is required." });
        }

        try {
            const roles = await Roles.search(searchTerm);
            res.json(roles);
        } catch (error) {
            console.error("Error searching roles:", error);
            res.status(500).json({ error: "Failed to search roles" });
        }
    }

    static async downloadRolesExcel(req, res) {
        try {
            const roles = await Roles.findAll();

            if (!roles || roles.length === 0) {
                return res.status(404).json({ message: "No roles found." });
            }

            const workbook = XLSX.utils.book_new();
            const worksheet = XLSX.utils.json_to_sheet(roles);
            XLSX.utils.book_append_sheet(workbook, worksheet, "Roles");

            const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            res.setHeader("Content-Disposition", "attachment; filename=roles.xlsx");
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            res.send(excelBuffer);
        } catch (error) {
            console.error("Error downloading Excel:", error);
            res.status(500).json({ error: "Failed to download Excel" });
        }
    }
}

module.exports = RolesController;
