const Position = require("../models/positionModel");

class PositionController {
    static async getAllPositions(req, res) {
        try {
            const positions = await Position.findAll();
            res.json(positions);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async getPositionById(req, res) {
        try {
            const position = await Position.findById(req.params.id);
            if (!position) {
                return res.status(404).json({ message: "Position not found" });
            }
            res.json(position);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async createPosition(req, res) {
        try {
            const { position_name, salary, employee_id } = req.body;
            if (!position_name || !salary || !employee_id) {
                return res.status(400).json({ message: "All fields are required" });
            }
            const position = await Position.create({ position_name, salary, employee_id });
            res.status(201).json(position);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updatePosition(req, res) {
        try {
            const { position_name, salary, employee_id } = req.body;
            const position = await Position.update(req.params.id, { position_name, salary, employee_id });
            if (!position) {
                return res.status(404).json({ message: "Position not found" });
            }
            res.json({ message: "Position updated successfully", position });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async deletePosition(req, res) {
        try {
            const result = await Position.delete(req.params.id);
            res.json(result);
        } catch (error) {
            if (error.message === "Position not found") {
                return res.status(404).json({ message: error.message });
            }
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = PositionController;
