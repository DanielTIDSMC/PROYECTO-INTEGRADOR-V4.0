const Category = require("../models/categoryModel");

class CategoryController {
    static async getAllCategories(req, res) {
        try {
            const categories = await Category.findAll();
            res.json(categories);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async getCategoryById(req, res) {
        try {
            const category = await Category.findById(req.params.id);
            if (!category) {
                return res.status(404).json({ message: "Category not found" });
            }
            res.json(category);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async createCategory(req, res) {
        try {
            const { name } = req.body;
            if (!name) {
                return res.status(400).json({ message: "Category name is required" });
            }
            const category = await Category.create({ name });
            res.status(201).json(category);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async updateCategory(req, res) {
        try {
            const { name } = req.body;
            if (!name) {
                return res.status(400).json({ message: "Category name is required" });
            }
            const updated = await Category.update(req.params.id, { name });
            if (!updated) {
                return res.status(404).json({ message: "Category not found" });
            }
            res.json({ message: "Category updated successfully" });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async deleteCategory(req, res) {
        try {
            const deleted = await Category.delete(req.params.id);
            if (!deleted) {
                return res.status(404).json({ message: "Category not found" });
            }
            res.json({ message: "Category deleted successfully" });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }

    static async searchCategories(req, res) {
        try {
            const { name } = req.query;
            if (!name) {
                return res.status(400).json({ message: "Search query is required" });
            }
            const categories = await Category.findAll({ where: { name } });
            res.json(categories);
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    }
}

module.exports = CategoryController;
