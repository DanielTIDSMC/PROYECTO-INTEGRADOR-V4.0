const pool = require("../config/db");

class Supplier {
  static async findAll(filters = {}) {
    const { name } = filters;
    let query = "SELECT * FROM supplier WHERE 1=1";
    const queryParams = [];

    if (name) {
      queryParams.push(`%${name}%`);
      query += ` AND name ILIKE $${queryParams.length}`;
    }

    const result = await pool.query(query, queryParams);
    return result.rows;
  }

  static async findById(id) {
    const query = "SELECT * FROM supplier WHERE id_supplier = $1";
    const result = await pool.query(query, [id]);
    return result.rows[0];
  }

  static async create(data) {
    const { name, company_address, phone, email, contact_info } = data;
    const result = await pool.query(
      "INSERT INTO supplier (name, company_address, phone, email, contact_info) VALUES ($1, $2, $3, $4, $5) RETURNING *",
      [name, company_address, phone, email, contact_info]
    );
    return result.rows[0];
  }

  static async update(id, data) {
    const { name, company_address, phone, email, contact_info } = data;
    const result = await pool.query(
      "UPDATE supplier SET name = $1, company_address = $2, phone = $3, email = $4, contact_info = $5, updated_at = CURRENT_TIMESTAMP WHERE id_supplier = $6 RETURNING *",
      [name, company_address, phone, email, contact_info, id]
    );
    return result.rows[0];
  }

  static async delete(id) {
    await pool.query("DELETE FROM supplier WHERE id_supplier = $1", [id]);
    return { message: "Supplier deleted successfully" };
  }
}

module.exports = Supplier;
