const pool = require("../config/db");

class Product {
    static async findAll() {
        const query = "SELECT * FROM product";
        const result = await pool.query(query);
        return result.rows;
    }

    static async findById(id) {
        const query = "SELECT * FROM product WHERE id_product = $1";
        const result = await pool.query(query, [id]);
        return result.rows[0];
    }

    static async create(data) {
        const { name, price, stock, expiration_date, id_category, max_capacity, min_capacity } = data;
        const query = `
            INSERT INTO product (name, price, stock, expiration_date, id_category, max_capacity, min_capacity, created_at, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, $7, NOW(), NOW())
            RETURNING *`;
        const values = [name, price, stock, expiration_date, id_category, max_capacity, min_capacity];
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    static async update(id, data) {
        const { name, price, stock, expiration_date, id_category, max_capacity, min_capacity } = data;
        const query = `
            UPDATE product
            SET name = $1, price = $2, stock = $3, expiration_date = $4, id_category = $5, max_capacity = $6, min_capacity = $7, updated_at = NOW()
            WHERE id_product = $8
            RETURNING *`;
        const values = [name, price, stock, expiration_date, id_category, max_capacity, min_capacity, id];
        const result = await pool.query(query, values);
        return result.rows[0];
    }

    static async delete(id) {
        const query = "DELETE FROM product WHERE id_product = $1";
        await pool.query(query, [id]);
        return { message: "Product deleted successfully" };
    }

    static async search(searchTerm) {
        const query = "SELECT * FROM product WHERE name ILIKE $1";
        const result = await pool.query(query, [`%${searchTerm}%`]);
        return result.rows;
    }
}

module.exports = Product;
