const pool = require("../config/db");

class User {
    static async findAll() {
        const query = "SELECT * FROM users";
        const result = await pool.query(query);
        return result.rows;
    }

    static async findById(id) {
        const query = "SELECT * FROM users WHERE id_user = $1";
        const result = await pool.query(query, [id]);
        return result.rows[0];
    }

    static async create(data) {
        const { name, password, creation_date, roles_id, employee_id } = data;
        const query = `
            INSERT INTO users (name, password, creation_date, roles_id, employee_id) 
            VALUES ($1, $2, $3, $4, $5) 
            RETURNING *`;
        const result = await pool.query(query, [name, password, creation_date, roles_id, employee_id]);
        return result.rows[0];
    }

    static async update(id, data) {
        const { name, password, creation_date, roles_id, employee_id } = data;
        const query = `
            UPDATE users 
            SET name = $1, password = $2, creation_date = $3, roles_id = $4, employee_id = $5, updated_at = CURRENT_TIMESTAMP 
            WHERE id_user = $6 
            RETURNING *`;
        const result = await pool.query(query, [name, password, creation_date, roles_id, employee_id, id]);
        return result.rows[0];
    }

    static async delete(id) {
        const query = "DELETE FROM users WHERE id_user = $1 RETURNING *";
        const result = await pool.query(query, [id]);
        return result.rows[0];
    }
}

module.exports = User;
